#include <iostream>
#include <unordered_map>
using namespace std;

int main() {
    int n;
    cout << "Enter the number of attendance records: ";
    cin >> n;
    
    unordered_map<int, int> mp;
    int sum = 0;
    int max_length = 0;
    
    
    mp[0] = -1;
    
    for (int i = 0; i < n; i++) {
        char attendance;
        cin >> attendance;
        
        //if attendance is P then increment sum by 1.
        if (attendance == 'P') {
            sum += 1;
        } else {  //if attendance == 'A'
            sum -= 1;
        }

        if (mp.find(sum) != mp.end()) {
            int length = i - mp[sum];
            max_length = max(max_length, length);
        } else {
            
            mp[sum] = i;
        }
    }
    
    cout << max_length << endl;
    
    return 0;
}
